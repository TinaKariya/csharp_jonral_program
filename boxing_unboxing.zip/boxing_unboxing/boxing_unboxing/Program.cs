﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace boxing_unboxing
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 20;
            object obj = a;
            Console.WriteLine("object type value:"+obj);

            int b = (int)obj;
            Console.WriteLine("type value:"+b);
            Console.Read();
        }
    }
}
