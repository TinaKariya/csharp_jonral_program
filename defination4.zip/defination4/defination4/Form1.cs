﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace defination4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            radioButton1.Checked = true;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                MessageBox.Show("You are selected Black !! ");
                return;
            }
            else if (radioButton2.Checked == true)
            {
                MessageBox.Show("You are selected Blue !! ");
                return;
            }
            else if (radioButton3.Checked == true)
            {
                MessageBox.Show("You are selected White !! ");
                return;
            }
            else
            {
                MessageBox.Show("Please Select Colour !! ");
                return;
            }
        }
    }
}
