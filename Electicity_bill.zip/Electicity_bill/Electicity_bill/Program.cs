﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Electicity_bill
{
    class Program
    {
        static void Main(string[] args)
        {
            int unit, u;
            double amt;
            Console.WriteLine("Enter total Unit:");
            unit = Convert.ToInt32(Console.ReadLine());
            u = unit / 100;
            switch (u)
            {
                case 0:
                case 1:
                    Console.WriteLine("Payable amount=" + (unit * 10));
                    break;
                case 2:
                    Console.WriteLine("Payable amount=" + ((unit * 10)+(unit-100)*15));
                    break;
                case 3:
                    Console.WriteLine("Payable amount=" + ((unit * 10)+(100*15)+(unit-200)+(unit-300)*25);
                    break;
            }
            Console.ReadKey();
        }
    }
}
