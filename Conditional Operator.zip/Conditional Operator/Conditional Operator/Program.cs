﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Conditional_Operator
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 5, y = 10, result;

            
            result = x > y ? x : y;

            
            Console.WriteLine("Result: " + result);

           
            result = x < y ? x : y;

           
            Console.WriteLine("Result: " + result);
            Console.Read();
        }
    }
}
