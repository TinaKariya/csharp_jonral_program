﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace do_while_poop
{
    class Program
    {
        static void Main(string[] args)
        {
            const int MAX = 5;
            int k = 0;

            do
            {

                System.Console.WriteLine("Do While Loop : {0}", k);

                k++;
            }
            while (k < MAX);
            Console.ReadKey();
        }
    }
}