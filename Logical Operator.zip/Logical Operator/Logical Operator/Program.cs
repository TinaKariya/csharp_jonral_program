﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Logical_Operator
{
    class Program
    {
        static void Main(string[] args)
        {
            bool t = true, r = false, result;

            
            result = t && r;
            Console.WriteLine("AND Operator: " + result);

            
            result = t || r;
            Console.WriteLine("OR Operator: " + result);

           
            result = !t;
            Console.WriteLine("NOT Operator: " + result);
            Console.Read();
        }
    }
}
